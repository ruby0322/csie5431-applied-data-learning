
gdown 1WrjcH5ZEZSx9bjy6jtGyYt_Ishc17Lhj
unzip ./checkpoint.zip
